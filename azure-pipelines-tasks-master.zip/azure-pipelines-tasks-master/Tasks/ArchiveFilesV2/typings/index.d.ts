/// <reference path="globals/node/index.d.ts" />
/// <reference path="globals/q/index.d.ts" />
// TODO: remove after you consume latest vsts-task-lib which carries lib
/// <reference path="./vsts-task-lib.d.ts" />
